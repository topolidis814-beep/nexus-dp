# NEXUS V1.2 — DEPLOY READY

Target Vercel project: nexus_v1_vercel_fixed-1
Git repository: topolidis814-beep/nexus-dp

Required Vercel environment variables:
- SUPABASE_URL
- SUPABASE_PUBLISHABLE_KEY

Expected health response after deployment:
{"ok":true,"name":"Nexus V1.2","database":"supabase"}

Deploy the CONTENTS of this archive at repository root.
Do not commit the ZIP itself as the application.
Do not commit secret/service-role keys.
