const url = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const key = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || '';
export const supabaseEnabled = Boolean(url && key);
async function request(path, {method='GET', body, token, prefer}={}) {
  const headers = {apikey:key, Authorization:`Bearer ${token || key}`, 'Content-Type':'application/json'};
  if(prefer) headers.Prefer=prefer;
  const r=await fetch(`${url}${path}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});
  const text=await r.text(); let data=null; try{data=text?JSON.parse(text):null}catch{data=text}
  if(!r.ok){const e=new Error(data?.msg||data?.message||data?.error_description||`Supabase ${r.status}`); e.status=r.status; throw e;} return data;
}
export async function signUp({email,password,metadata}){return request('/auth/v1/signup',{method:'POST',body:{email,password,data:metadata}})}
export async function signIn({email,password}){return request('/auth/v1/token?grant_type=password',{method:'POST',body:{email,password}})}
export async function getUser(token){return request('/auth/v1/user',{token})}
export async function signOut(token){return request('/auth/v1/logout',{method:'POST',token})}
export async function select(table, query='', token){return request(`/rest/v1/${table}?${query}`,{token})}
export async function insert(table, body, token){return request(`/rest/v1/${table}`,{method:'POST',body,token,prefer:'return=representation'})}
export async function update(table, query, body, token){return request(`/rest/v1/${table}?${query}`,{method:'PATCH',body,token,prefer:'return=representation'})}
